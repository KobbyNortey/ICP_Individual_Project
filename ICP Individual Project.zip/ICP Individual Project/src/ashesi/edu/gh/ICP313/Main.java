package ashesi.edu.gh.ICP313;

import java.io.*;
import java.util.*;


/**
 * @author Shawn Nii Nortey Owusu-Nortey
 * @version 1.0.0
 */
public class Main {
    


    public static void main(String[] args) throws IOException {
        ArrayList<String> file_contents = readFile();
        String startCity = file_contents.get(0);
        String startCountry = file_contents.get(1);
        String destinationCity = file_contents.get(2);
        String destinationCountry = file_contents.get(3);

        ArrayList<ArrayList<String>> all_paths = null;
        Airport starting = new Airport(startCity, startCountry);
        Airport destination = new Airport(destinationCity, destinationCountry);
        Map<String, String> starting_airports = starting.rg_airports();
        Map<String, String> destination_airports = destination.rg_airports();

        ArrayList<String> available_airlines = Company.available;

        Route my_route = new Route(available_airlines);
        my_route.get_routebeginning(starting_airports);

        boolean found1 = false;
        boolean found_multiple_paths = false;

//        find routes
        for (String airport : destination_airports.keySet()) {
            found1 = my_route.check_one_step(airport);
            found_multiple_paths = my_route.find_multi_Path(airport);
        }
        if (found1 || found_multiple_paths) {
            all_paths = my_route.path;
        } else{
            System.out.println("No route found");
            System.exit(0);
        }

//      find optimal route
        HashMap<ArrayList<String>, Double> optimals = optimalPath(all_paths);

//      write optimal route to file
        writable(optimals);
    }

    /**
     * reads input file
     * @return returns start city, start country, stop city, and stop country
     */
    static ArrayList<String> readFile(){
        Scanner fileReader = null;
        try {
            fileReader = new Scanner(new FileInputStream("input.txt"));
        } catch (FileNotFoundException fnf) {
            System.out.println(fnf.getMessage());
            System.out.println("Enter valid input file");
        }
        assert fileReader != null;
        String[] line1 = fileReader.nextLine().split(",");
        String[] line2 = fileReader.nextLine().split(",");

        String start_city;
        String start_country;

        String destination_city;
        String destination_country;

        start_city = line1[0];
        start_country = line1[1].strip();

        destination_city = line2[0];
        destination_country = line2[1].strip();


        if(line1.length > 2){
            int go = 0;
            StringBuilder replaced_city = new StringBuilder();
            while(go < line1.length - 1){
                if(go == line1.length - 2){
                    replaced_city.append(line1[go]);
                } else{
                    replaced_city.append(line1[go]).append(",");
                }
                go++;
            }
            start_city = replaced_city.toString();
            start_country = line1[2].strip();
        } else if(line2.length > 2){
            int go = 0;
            String replaced_city = "";
            while(go < line2.length - 1){
                if(go == line2.length - 2){
                    replaced_city += line2[go];
                } else{
                    replaced_city += line2[go] + ",";
                }
                go++;
            }
            destination_city = replaced_city;
            destination_country = line2[2].strip();
        }
        System.out.println(start_city);
        System.out.println(start_country);
        System.out.println(destination_city);
        System.out.println(destination_country);

        ArrayList<String> individuals = new ArrayList<>();
        individuals.add(start_city);
        individuals.add(start_country);
        individuals.add(destination_city);
        individuals.add(destination_country);

        return individuals;
    }

    /**
     * finds optimal path amongst all possible paths
     * @param all_paths a list of lists of all possible paths
     * @return a hashmap of optimal path and optimal distance
     */
    static HashMap<ArrayList<String>, Double> optimalPath(ArrayList<ArrayList<String>> all_paths){
        HashMap<ArrayList<String>, Double> arrayListDoubleHashMap = new HashMap<>();
        double total;
        ArrayList<String> optimal_path = new ArrayList<>();
        double optimal_distance = Double.POSITIVE_INFINITY;
        Map<String, String> all_airports;
        all_airports = Airport.all_airports;

//      optimal path calculation
        for (ArrayList<String> path : all_paths) {
            total = (double) 0;
            for (String smaller_path : path) {
                String[] start_stop = smaller_path.split(",");
                String start = start_stop[0].substring(1);
                String stop = start_stop[1].substring(1, 4);

                double start_lat = Double.parseDouble(all_airports.get(start).split(",")[1]);
                double start_long = Double.parseDouble(all_airports.get(start).split(",")[2].substring(1, 8));

                double stop_lat = Double.parseDouble(all_airports.get(stop).split(",")[1]);
                double stop_long = Double.parseDouble(all_airports.get(stop).split(",")[2].substring(1, 8));

                double distance = haversine(start_lat, start_long, stop_lat, stop_long);

                total += distance;

                if(total < optimal_distance){
                    optimal_distance = total;
                    optimal_path = path;
                }
            }

        }
        arrayListDoubleHashMap.put(optimal_path, optimal_distance);
        return arrayListDoubleHashMap;
    }

    /**
     * writes solution to output file
     * @param hashMap maps a string array list to a double
     */
    static void writable(HashMap<ArrayList<String>, Double> hashMap) throws FileNotFoundException {
        ArrayList<String> optimal_path = null;
        int numbering = 0;
        int total_stops = 0;

        PrintWriter outputStream = null;
//      file opening

        outputStream = new PrintWriter(new FileOutputStream("optimal_route.txt"));

//       optimal path
        for(ArrayList<String> path: hashMap.keySet()){
            optimal_path = path;
        }
//       optimal distance
        double optimal_distance = hashMap.get(optimal_path);

        assert optimal_path != null;
        for(String path: optimal_path){
            numbering+=1;
            String[] start_stop = path.split(",");
            String start = start_stop[0].substring(1);
            String destination = start_stop[1].substring(1, 4);
            ArrayList<String> airport_code_stops = Route.get_airportID_stops(start, destination);
            assert airport_code_stops != null;
            String airline_code = airport_code_stops.get(0);


            int stops = Integer.parseInt(airport_code_stops.get(1));
            outputStream.println("\t" + numbering + ". " + airline_code + " from " + start + " to " + destination + " " + stops + " stops");
            total_stops += stops;

        }
//        information output streams
        outputStream.println("Total flights: " + numbering);
        outputStream.println("Total additional stops: " + total_stops);
        outputStream.println("Total distance: " + Math.round(optimal_distance)+" km");
        outputStream.println("Optimality criteria: Total distance");
        outputStream.close();
    }

    /**
     *
     * @param first_latitude latitude of start airport
     * @param first_longitude longitude of start airport
     * @param second_latitude latitude of destination airport
     * @param second_longitude longitude of destination airport
     * @return distance between two airports
     */
    static Double haversine(double first_latitude, double first_longitude,
                                double second_latitude, double second_longitude) {
        // distance between latitudes and longitudes
        double latitude = Math.toRadians(second_latitude - first_latitude);
        double longitude = Math.toRadians(second_longitude - first_longitude);

        // formula
        double a = Math.pow(Math.sin(latitude / 2), 2) +
                Math.pow(Math.sin(longitude / 2), 2) *
                        Math.cos(first_latitude) *
                        Math.cos(second_latitude);
        double rad = 6371;
        double c = 2 * Math.asin(Math.sqrt(a));
        return rad * c;
    }
}


